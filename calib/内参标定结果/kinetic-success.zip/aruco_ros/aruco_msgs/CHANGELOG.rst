^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aruco_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.4 (2019-08-28)
------------------

0.2.3 (2018-04-20)
------------------
* Kinetic devel merge
* Contributors: Victor Lopez

0.2.2 (2017-07-25)
------------------

0.2.1 (2017-07-21)
------------------

0.2.0 (2016-10-19)
------------------

0.1.0 (2015-08-10)
------------------
* Update changelogs and maintainer email
* Contributors: Bence Magyar

0.0.1 (2015-05-20)
------------------
* Reorganize aruco_ros into 3 packages
* Contributors: Bence Magyar
