^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aruco_mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.4 (2015-10-11)
------------------
* msg file addopted to  coding style rules
* Contributors: durovsky

1.0.3 (2015-10-10)
------------------
* updated package.xml
* Contributors: durovsky

1.0.2 (2015-10-10)
------------------
* added visualization_msgs dependency
* Contributors: durovsky

1.0.1 (2015-10-09)
------------------
* 1.0.0
* CHANGELOG
* fix
* adding CHANGELOG
* removed pal_vision_segmentation dependency
* Contributors: durovsky

1.0.0 (2015-10-09)
------------------
* removed pal_vision_segmentation dependency
* Contributors: durovsky


0.1.0 (2015-10-09)
------------------
* prerelease version
* version 1.0.0
* Contributors: Frantisek Durovsky, durovsky
